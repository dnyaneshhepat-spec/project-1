export { default } from "./TermsAndConditionsDialog";
