export { default } from "./RegisterPage";
